﻿! function (e) {
    var t = "1337xy",
        a = e.path + "logo.png";
    e.path;
    var i = "",
        c = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
        r = [
            ["Филми", "cat/Movies/", "movies.png"],
            ["Сериали", "cat/TV/", "series.png"],
            ["Документални", "cat/Documentaries/", "docu.png"],
            ["Музика", "cat/Music/", "music.png"],
            ["Аниме", "cat/Anime/", "anime.png"],
            ["18+", "cat/XXX/", "18+.png"],
        ];

    function s(t, i, c) {
        t.type = "directory", t.contents = "items", t.metadata.logo = c ? e.path + c : a, t.metadata.icon = c ? e.path + c : a, t.metadata.title = new showtime.RichText(i), t.metadata.background = e.path + "bg.jpg"
    }
    var n = "FFA500",
        p = "FFFFFF";

    function l(e, t, a) {
        return "<font " + (a ? 'size="' + a + '" ' : "") + 'color="' + t + '">' + e + "</font>"
    }
    var $ = e.createService(e.getDescriptor().title, e.getDescriptor().id + ":start", "video", !0, a),
        o = e.createSettings(e.getDescriptor().id, a, e.getDescriptor().title);

    function d(e, t, a) {
        h(e, "search/" + t.replace(/\s/g, "+") + "/", a)
    }

    function g(e, a) {
        a.addOptURL("Търсене на '" + a.title.replace(/\s*-*\s*Season\s*\d+\s*-\s*\d+\s*/g, "") + "' в 1337x", t + ":search:" + a.title.replace(/\s*-*\s*Season\s*\d+\s*-\s*\d+\s*/g, ""), "search"), a.addOptURL("в Zamunda", "pluginsBG:znt:search:" + a.title, "search"), a.addOptURL("в Zelka", "pluginsBG:zse:search:" + a.title, "search"), a.addOptURL("в ArenaBG", "pluginsBG:abg:search:" + a.title, "search"), a.addOptURL("в tGX", "tey:tgx:search:" + a.title, "search"), a.addOptURL("в YTS", "tey:yts:search:" + a.title, "search"), a.addOptURL("в ezTV", "tey:etv:search:" + a.title, "search"), a.addOptURL("Навсякъде", "search:" + a.title, "search")
    }

    function h(e, r, s) {
        e.loading = !0;
        var o = 0,
            d = 0,
            h = 1,
            _ = i,
            u = null,
            m = 0,
            R = "search/" == r.substr(0, 6);
        "top-100-movies" != r && r.length && (R && 0 > r.indexOf("search/") ? _ += r : _ = r);
        var x = /href="\/sub\/(?:movies|tv|documentaries|music|anime|xxx|1|2|3|4|5|6|7|9|22|23|24|25|26|27|28|41|42|48|49|50|51|53|54|55|58|59|60|66|68|69|70|71|73|74|75|76|78|79|80|81)\/[\s\S]*?"[\s\S]*?href="\/(torrent\/[\s\S]*?\/)">([\s\S]*?)<[\s\S]*?seeds">(\d+)[\s\S]*?leeches">(\d+)[\s\S]*?date">([\s\S]*?)<[\s\S]*?size [\s\S]*?">([\s\S]*?)</gi;

        function D() {
            var i, c = "",
                r = "",
                h = "",
                _ = "",
                R = "",
                D = "",
                A = "",
                S = null,
                B = 0,
                f = 0,
                v = [],
                y = 0,
                H = x.exec(u);
            if (null == H) return !1;
            for (; H;) {
                d++, c = H[1];
                var w = new Date().getFullYear();
                seeder = H[3].trim(), leecher = H[4].trim(), m = H[5].replace(/\d+(?:am|pm) (\w{3}). (\d+).*/g, "$2/$1/" + w).replace(/(\d+):(\d{2})(\w+)/g, "днес").replace(/(\w{3}). (\d+).* '(\d+)/g, "$2/$1/20$3").replace(/Jan/i, "01").replace(/Feb/i, "02").replace(/Mar/i, "03").replace(/Apr/i, "04").replace(/May/i, "05").replace(/Jun/i, "06").replace(/Jul/i, "07").replace(/Aug/i, "08").replace(/Sep/i, "09").replace(/Oct/i, "10").replace(/Nov/i, "11").replace(/Dec/i, "12"), h = "Размер: " + l(H[6], p) + l("<br>Пиъри: ", n) + l(seeder + "/" + leecher, p) + l("<br>Добавен: ", n) + l(m, p), ctitle = "Пиъри: " + seeder + "/" + leecher + " (" + H[6] + ")", A = _ = H[2].replace(/\.|,/g, " ").replace(/{/g, "(").replace(/}/g, ")").replace(/_/g, " ").replace(/<[^>]*>/g, "").replace(/\s\s/g, " "), R = _, 0 > r.indexOf("http") && (r = $.baseURL + r), y = 0, v = [], D = "", S = null, B = 0, f = 0;
                var b = _.match(/([\s\S]*?)(?:[\.\s\((\[]((?:19[2-9]|20[0-2])\d)[\]\)]?)?[\.|\s]S(\d+)\s?E(\d+)[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|F?HD|4K|3D|HDTV|HDCAM|DVB|DVD(?:Rip)?|HBO|AMZN|NF|HULU|AC3|HDRip|PAL|NTSC|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB(?:Rip)?|XviD|AVC|HEVC|[x|h]264|[x|h]265|TC|BgAudio)/i);
                if (b) S = b[2], _ = b[1].replace(/[\.\s\(\[](?:19[2-9]|20[0-2])\d[\]\)]?/gi, "") + " " + b[3] + "x" + b[4] + l(" (" + b[5] + ")", "A0A0A0", "+2"), D = b[1].trim(), B = parseInt(b[3]), f = parseInt(b[4]);
                else if ((b = R.match(/([\s\S]*?)[\.|\s]S(\d+)E(\d+)/i)) || (b = _.match(/([\s\S]*?)[\.|\s]S(\d+)E(\d+)/i)), b || (b = R.match(/([\s\S]*?)[\.|\s](\d+)x(\d+)/i)), b || (b = _.match(/([\s\S]*?)[\.|\s](\d+)x(\d+)/i)), b) _ = b[1].replace(/[\.\s\(\[](?:19[2-9]|20[0-2])\d[\]\)]?/gi, "") + " " + b[2] + "x" + b[3], D = b[1].trim(), B = parseInt(b[2]), f = parseInt(b[3]);
                else if ((b = _.match(/([\s\S]*?)[\.|\s](?:-\s)?S(\d+)[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|F?HD|4K|3D|HDTV|HDCAM|DVB|DVD(?:Rip)?|HBO|AMZN|NF|HULU|AC3|HDRip|PAL|NTSC|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB(?:Rip)?|XviD|AVC|HEVC|[x|h]264|[x|h]265|TC|BgAudio)/i)) || (b = _.match(/([\s\S]*?)[\.|\s](?:-\s)?Season[\s](\d+)[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|F?HD|4K|3D|HDTV|HDCAM|DVB|DVD(?:Rip)?|HBO|AMZN|NF|HULU|AC3|HDRip|PAL|NTSC|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB(?:Rip)?|XviD|AVC|HEVC|[x|h]264|[x|h]265|TC|BgAudio)/i)), b || (b = _.match(/([\s\S]*?)[\.|\s](?:-\s)?Season[\s](\d)[\S\s]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|F?HD|4K|3D|HDTV|HDCAM|DVB|DVD(?:Rip)?|HBO|AMZN|NF|HULU|AC3|HDRip|PAL|NTSC|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB(?:Rip)?|XviD|AVC|HEVC|[x|h]264|[x|h]265|TC|BgAudio)/i)), b || (b = _.match(/([\s\S]*?)[\.|\s](?:-\s)?Season[\s]([\d][\d])/i)), b || (b = _.match(/([\s\S]*?)[\.|\s](?:-\s)?Season[\s]([\d])/i)), b) _ = b[3] ? b[1].replace(/\s*-*\s*Season\s*\d+\s*-?\d*/gi, "").replace(/[\.\s\(\[](?:19[2-9]|20[0-2])\d[\]\)]?/gi, "") + " - Сезон " + parseInt(b[2]) + " " + l(" (" + b[3] + ")", "A0A0A0", "+2") : b[1].replace(/\s*-*\s*Season\s*\d+\s*-?\d*/gi, "").replace(/[\.\s\(\[](?:19[2-9]|20[0-2])\d[\]\)]?/gi, "") + " - Сезон " + parseInt(b[2]), D = b[1].trim(), B = parseInt(b[2]), f = 99;
                else if (b = _.match(/([\s\S]*?)[\.\s\(\[]((?:19[2-9]|20[0-2])\d)[\]\)]?[\.\s\S]*?(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|F?HD|4K|3D|HDTV|HDCAM|DVB|DVD(?:Rip)?|HBO|AMZN|NF|HULU|AC3|HDRip|PAL|NTSC|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB(?:Rip)?|XviD|AVC|HEVC|[x|h]264|[x|h]265|TC|BgAudio)[\.\s\[\(\-]*(480[p|i]|576[p|i]|720[p|i]|1080[p|i]|2160[p|i]|UHD|F?HD|4K|3D|HDTV|HDCAM|DVB|DVD(?:Rip)?|HBO|AMZN|NF|HULU|AC3|HDRip|PAL|NTSC|BRRip|BDRip|BluRay|Blu-Ray|BDRemux|WEB(?:Rip)?|XviD|AVC|HEVC|[x|h]264|[x|h]265|TC|BgAudio)?/i)) {
                    var U = "";
                    null != b[3] && (U = b[3] + " ");
                    var T = "";
                    null != b[4] && (T = b[4] + " "), _ = b[1] + l("  (" + U + T + b[2] + ") ", "A0A0A0", "+2"), D = b[1].trim(), S = parseInt(b[2])
                } else (b = R.match(/([\s\S]*?)[\:|\/|\.|\(|\?|\-|\–]/i)) || (b = _.match(/([\s\S]*?)[\:|\/|\.|\(|\?|\-|\–]/i)), b && (_ = R, D = b[1].trim());
                v = [], R = R.trim(), R += "<hr>", i = null, title_base2 = D, B > 0 ? f > 0 && f < 99 ? title_base2 += " - " + B + "x" + (f < 10 ? "0" : "") + f : title_base2 += " - Сезон " + B : S > 1919 && S < 2030 && (title_base2 += " (" + S + ")"), A.indexOf("265") > 0 && (_ += l(" (x265) ", "AAAAAA", "+2"));
                var C = {
                    url: c,
                    title: _,
                    season: B,
                    episode: f >= 0 ? f : 0,
                    icon: r,
                    genre: h,
                    tagline: A,
                    title_base: D,
                    title_base2: title_base2
                };
                if ((i = e.appendItem(t + ":entry:" + Duktape.enc("base64", showtime.JSONEncode(C)), "video", {
                    icon: a,
                    backdrops: [{
                        url: v[1]
                    }, {
                        url: v[2]
                    }, {
                        url: v[3]
                    }, {
                        url: v[4]
                    },],
                    title: new showtime.RichText(_),
                    tagline: A.replace(/&#039;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&"),
                    year: S,
                    ctitle: new showtime.RichText(l(ctitle, "AAAAAA", 2)),
                    description: new showtime.RichText(l(h + (S > 1919 ? l("\nГодина: ", n) + S : ""), n))
                })).date = m, D.length > 2 && (i.title = D, g(e, i)), o++, e.entries++, e.entries > 10 && (e.loading = !1), H = x.exec(u), o >= s) return !1
            }
            return !0
        }

        function A() {
            if (o >= s) return !1;
            ret = !0;
            var t = h + 1;
            R && (t = h + 1 + (parseInt($.results) + 50) / 50), e.loading = !0;
            for (var a = h; a < t; a++)
                if (last_offset = o, "top-100" == _ ? (u = showtime.httpReq($.baseURL + _, {
                    headers: {
                        "User-Agent": c
                    },
                    caching: $.caching,
                    compression: !0,
                    cacheTime: !0 == $.caching ? 3600 : 0,
                    ignoreErrors: true    // ← allow reading even on HTTP 403/404
                }).toString(), D()) : (u = showtime.httpReq($.baseURL + _ + a + "/", {
                    headers: {
                        "User-Agent": c
                    },
                    caching: $.caching,
                    compression: !0,
                    cacheTime: !0 == $.caching ? 3600 : 0,
                    ignoreErrors: true    // ← allow reading even on HTTP 403/404
                }).toString(), D(), h++), o == last_offset && (ret = !1), "top-100" != r && d < 20 && (ret = !1), o >= s && (ret = !1), !ret) {
                    o = s + 1;
                    break
                } return e.loading = !1, ret
        }
        A(), e.paginator = A, e.loading = !1
    }
    o.createString("key", "API ключ за omdbapi.com", "2c51d559", function (e) {
        key = e
    }), o.createBool("metadata", "Метаданни от omdbapi.com", !0, function (e) {
        $.metadata = e
    }), o.createMultiOpt("baseURL2", "Сървър", [
        ["https://www.1337x.to/", "1337x.to", !0],
        ["https://www.1337xx.to/", "1337xx.to"],
        ["https://www.1337xxx.to/", "1337xxx.to"],
        ["https://www.1337x.tw/", "1337xx.tw"],
        ["https://1337xto.to/", "1337xto.to"]
    ], function (e) {
        $.baseURL = e
    }), o.createBool("caching", "Кеширане на страницата", !1, function (e) {
        $.caching = e
    }), o.createMultiOpt("results", "Брой резултати", [
        [50, 50, !0],
        [100, 100]
    ], function (e) {
        $.results = e
    }), o.createBool("xxx", "Категория 18+", !0, function (e) {
        $.xxx = e
    }), e.addURI(t + ":entry:(.*)", function (t, i) {
        t.flush(),
            function t(i, r) {
                var o = showtime.JSONDecode(0 == r.indexOf("{") ? r : Duktape.dec("base64", r));
                s(i, o.title_base2), i.loading = !0;
                var d = [],
                    g = "",
                    h = "",
                    _ = null,
                    u = null,
                    m = 0,
                    R = "",
                    x = 0,
                    D = "",
                    A = showtime.httpReq($.baseURL + o.url, {
                        caching: $.caching,
                        compression: !0,
                        cacheTime: !0 == $.caching ? 864e3 : 0,
                        headers: {
                            "User-Agent": c
                        },
                        ignoreErrors: true    // ← allow reading even on HTTP 403/404
                    }).bytes.toString();
                i.loading = !1;
                var S = /(magnet:[\s\S]*?)"/i.exec(A),
                    B = /<div class="torrent-image">\s?<img src="[\s\S]*?"\salt=[\s\S]*?(\d+)%[\s\S]*?<div class="torrent-category clearfix">\s*(?:<[^>]*>)?([\s\S]*?)(?:<[^>]*>)?\s*<\/div>\s*<p>\s([\s\S]*?)\s<\/p>/i.exec(A),
                    f = /(?:\s|\/|")(tt\d+)(?=\/|\s|")/i.exec(A),
                    v = /Downloads(?:<[^>]*>\s*)*(\d+)</i.exec(A);
                if (S) h = S[1].replace(/(\&amp;)/g, "&"), D = v[1];
                else {
                    showtime.notify("Проблемен торент, опитайте с друг. Върнете назад, задръжте ОК на заглавието, после Търсене в 1337x", 5);
                    return
                }
                if ((!B || f) && $.metadata) {
                    if (f && $.metadata) {
                        _ = f[1];
                        try {
                            var y = showtime.httpReq("https://www.omdbapi.com/?apikey=" + key + "&i=" + _, {
                                caching: $.caching,
                                compression: !0,
                                cacheTime: !0 == $.caching ? 864e3 : 0,
                                headers: {
                                    "User-Agent": c
                                },
                                ignoreErrors: true    // ← allow reading even on HTTP 403/404
                            }).bytes.toString()
                        } catch (H) {
                            if (showtime.notify("Няма връзка с omdbapi.com или объркан ключ от настройките на 1337x", 5), B) {
                                try {
                                    g = B[3].replace(/\n\n/g, "<br>").replace(/\n/g, " ")
                                } catch (w) { }
                                try {
                                    R = B[2].replace(/(?:<[^>]*>)+/g, ", ").replace(/\n\n/g, "<br>").replace(/\n/g, " ")
                                } catch (b) { }
                                try {
                                    x = B[1].replace(/00/g, 0)
                                } catch (U) { }
                                try {
                                    u = a
                                } catch (T) { }
                            } else g = "", R = "", x = 0, u = a
                        }
                        try {
                            R = y.match(/Genre":"([\s\S]*?)",/i)[1].replace(/N\/A/g, "")
                        } catch (C) { }
                        try {
                            m = parseInt(y.match(/Runtime":"([\s\S]*?)",/i)[1].replace(/N\/A/g, 0))
                        } catch (V) { }
                        try {
                            g = y.match(/Plot":"([\s\S]*?)","/i)[1].replace(/\\"/g, '"').replace(/N\/A/g, "")
                        } catch (L) { }
                        try {
                            u = y.match(/Poster":"([\s\S]*?)",/i)[1].replace(/N\/A/g, a)
                        } catch (N) { }
                        try {
                            x = 10 * parseInt(y.match(/imdbRating":"([\s\S]*?)",/i)[1].replace(/N\/A/g, 0))
                        } catch (O) { }
                    } else g = "", R = "", x = 0, u = a
                } else {
                    try {
                        g = B[3].replace(/\n\n/g, "<br>").replace(/\n/g, " ")
                    } catch (F) { }
                    try {
                        R = B[2].replace(/(?:<[^>]*>)+/g, ", ").replace(/\n\n/g, "<br>").replace(/\n/g, " ")
                    } catch (M) { }
                    try {
                        x = B[1].replace(/00/g, 0)
                    } catch (E) { }
                    try {
                        u = a
                    } catch (I) { }
                }
                var k = i.appendItem(h, "video", {
                    icon: u,
                    backdrops: [{
                        url: d[1]
                    }, {
                        url: d[2]
                    }, {
                        url: d[3]
                    }, {
                        url: d[4]
                    },],
                    title: new showtime.RichText(l(o.title, n)),
                    genre: new showtime.RichText(l("Свален: ", n) + l(D, p) + " пъти<br>" + l(o.genre, n)),
                    rating: parseInt(x),
                    source: new showtime.RichText(l(R.trim().replace(/\s,\s+/g, ", "), n)),
                    description: new showtime.RichText(g),
                    year: o.year,
                    duration: m > 0 ? 60 * m : null
                });
                o.title_base.length > 2 && (k.title = o.title_base), i.appendItem("tey:tgx:search:" + o.title_base + (o.season > 0 ? (o.season < 10 ? " S0" : " S") + o.season + (o.episode > 98 ? "" : (o.episode < 10 ? "E0" : "E") + o.episode) : ""), "video", {
                    icon: e.path + "tgx.png",
                    genre: new showtime.RichText(l(o.genre, n)),
                    title: "Гледай от tGX",
                    description: "Изисква се добавка: tGX",
                    source: new showtime.RichText(l(R.trim(), n)),
                    duration: m > 0 ? 60 * m : null
                }), u != a && (i.appendItem(u, "image", {
                    title: "Плакат"
                }), $.poster && (i.metadata.background = u, i.metadata.backgroundAlpha = .25, i.metadata.backgroundAvailable = !0)), i.loading = !1
            }(t, i)
    }), e.addURI(t + ":genre:(.*)", function (t, a) {
        s(t, r[a][0], r[a][2]), t.flush(), t.metadata.glwview = e.path + "list.view", h(t, r[a][1], 1200)
    }), e.addURI(t + ":search:(.*)", function (t, a) {
        s(t, "Резултати за '" + a + "'", null), t.metadata.glwview = e.path + "list.view", d(t, a, 1200)
    }), e.addURI(t + ":genres", function (a) {
        if (s(a, "Категории"), a.flush(), $.xxx) var i = r;
        else var i = r.slice(0, -1);
        for (var c in i) a.appendItem(t + ":genre:" + c, "directory", {
            title: i[c][0],
            icon: e.path + i[c][2]
        })
    }), e.addURI(t + ":top-100", function (t) {
        s(t, "Топ 100"), t.flush(), t.metadata.glwview = e.path + "list.view", h(t, "top-100", 100)
    }), e.addURI(e.getDescriptor().id + ":start", function (c) {
        var r;
        c.metadata.glwview = e.path + "list.view", s(c, e.getDescriptor().synopsis), c.entries = 1, c.loading = !0, i = "", i += "top-100", (r = c).appendItem(t + ":search:", "search", {
            title: "Търсене"
        }), r.appendItem(t + ":genres", "directory", {
            icon: a,
            title: "Категории"
        }), r.appendItem("", "separator", {
            title: new showtime.RichText(l("Топ 100", n, "+2"))
        }), h(r, "top-100", 10), r.appendItem(t + ":top-100", "directory", {
            icon: a,
            title: "Още... ►"
        }), r.loading = !1, c.loading = !1
    }), e.addSearcher(e.getDescriptor().title, a, function (e, t) {
        d(e, t, $.results)
    })
}(this);